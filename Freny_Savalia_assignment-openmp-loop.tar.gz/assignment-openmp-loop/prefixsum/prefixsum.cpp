#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
using namespace std;


#ifdef __cplusplus
extern "C" {
#endif
  void generatePrefixSumData (int* arr, size_t n);
  void checkPrefixSumResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand

  if (argc < 3) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  
  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);

  int * arr = new int [n];
  generatePrefixSumData (arr, n);

  int * pr = new int [n+1];
  
  int * t = new int [nbthreads-1];  
  t[0]=0;
  int end;
  omp_set_num_threads(nbthreads);
  
  //for(int i=0;i<n;i++){
      //cout<<"A[i]"<<arr[i]<<endl;
  //}

   
  #pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }

  int start = 0;
  //pr[0] = 0;
  auto t1=std::chrono::high_resolution_clock::now();
  #pragma omp parallel for schedule(dynamic)
   for(int i=0;i<nbthreads;i++){
      if(i == nbthreads-1){
        end = n;
      }
      else{
        end = (n/nbthreads) * (i+1);
      }
      for(int j=start;(j<end)&&(j<n);j++){
         if(j==start){
           pr[j+1]=arr[j];
	 }
         else{
           pr[j+1]=pr[j]+arr[j];
         }
      }
      
      start = end;
      //cout<<"New Start"<<start;
   }

   //for(int i=0;i<n+1;i++){
      //cout<<"P[i]"<<pr[i]<<endl;
   //}

  //insert prefix sum code here 
   for(int f=1;f<nbthreads;f++){
      int el = (n/nbthreads) * f;
      int l = pr[el];
      t[f]=l;
   }
   
   for(int i=1;i<nbthreads;i++){
      t[i]=t[i]+t[i-1];
   }
   
   //for(int i=0;i<nbthreads;i++){
      //cout<<"T"<<t[i]<<endl;
   //}

   int s = 0;

   #pragma omp parallel for schedule(dynamic)
   for(int i=0;i<nbthreads;i++){
      if(i == nbthreads-1){
        end = n;
      }
      else{
        end = (n/nbthreads) * (i+1);
      }
      
      for(int j=s;(j<=end)&&(j<=n);j++){
         pr[j]=pr[j]+t[i];
      }
      
      s = end+1;
      //cout<<"New Start"<<start;
   }

   //for(int i=0;i<n+1;i++){
      //cout<<i<<"AP[i]"<<pr[i]<<endl;
   //}

  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();
  
  checkPrefixSumResult(pr, n);

  delete[] arr;  
  return 0;
}
