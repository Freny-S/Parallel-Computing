#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <chrono>
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif



int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
  

  int functionid=std::stoi(argv[1]);
  float a=std::stof(argv[2]);
  //printf("\nA: %f",a);
  float b=std::stof(argv[3]);
  //printf("\nB: %f",b);
  int n=std::stoi(argv[4]);
  //printf("\nN: %d",n);
  int intensity=std::stoi(argv[5]);
  int nbthreads = stoi(argv[6]);
  char* sched_type = argv[7];
  int granularity = stoi(argv[8]);
  omp_set_num_threads(nbthreads);
  
  if(strcmp(sched_type,"static") == 0){
	omp_set_schedule(omp_sched_static,granularity);
  }
  else if(strcmp(sched_type,"dynamic") == 0){
	omp_set_schedule(omp_sched_dynamic,granularity);
  }
  else if(strcmp(sched_type,"guided") == 0){
	omp_set_schedule(omp_sched_guided,granularity);
  }
  
  float u;
  u=(float)(b-a)/n;
  //printf("\nU: %f",u);
  float x;
  float result;
  float sum;

  auto t1=std::chrono::high_resolution_clock::now();

#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  if (argc < 9) {
    std::cerr<<"Usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }

  //insert code here
  switch(functionid){
  case 1:
       #pragma omp parallel for reduction(+ :sum) schedule(runtime)
       for(int i=0; i<n; i+=1){
           x=(a+(i+0.5)*u);
	   sum+=f1(x,intensity);
       }
       break;
  case 2:
       #pragma omp parallel for reduction(+ :sum) schedule(runtime)
       for(int i=0; i<n; i+=1){
           x=(a+(i+0.5)*u);
           sum+=f2(x,intensity);
       }
       break;
       
  case 3:
       #pragma omp parallel for reduction(+ :sum) schedule(runtime)
       for(int i=0; i<n; i+=1){
           x=(a+(i+0.5)*u);
           sum+=f3(x,intensity);
       }
       break;
  case 4:
       #pragma omp parallel for reduction(+ :sum) schedule(runtime)
       for(int i=0; i<n; i+=1){
           x=(a+(i+0.5)*u);
           sum+=f4(x,intensity);
       }
       break;
  default:
       std::cout<<"\nPlease enter an integer value between 1 to 4\n";
       break;
  }
  //printf("\nSUM: %f",sum);
  result=u*sum;
  std::cout<<result<<endl;

  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();

  return 0;
}

