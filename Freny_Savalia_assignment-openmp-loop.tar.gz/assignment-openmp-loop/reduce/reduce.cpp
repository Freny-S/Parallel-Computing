#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <string.h>
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif
  void generateReduceData (int* arr, size_t n);
#ifdef __cplusplus
}
#endif

int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
  if (argc < 5) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }
  
  float sum = 0.0;
  int n = atoi(argv[1]);
  int * arr = new int [n];
  int nbthreads = stoi(argv[2]);
  char* sched_type = argv[3];
  int granularity = stoi(argv[4]);
  omp_set_num_threads(nbthreads);
  
  if(strcmp(sched_type,"static") == 0){
	omp_set_schedule(omp_sched_static,granularity);
  }
  else if(strcmp(sched_type,"dynamic") == 0){
	omp_set_schedule(omp_sched_dynamic,granularity);
  }
  else if(strcmp(sched_type,"guided") == 0){
	omp_set_schedule(omp_sched_guided,granularity);
  }
  auto t1=std::chrono::high_resolution_clock::now();
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  
  
  
  generateReduceData (arr, atoi(argv[1]));
  
  //insert reduction code here
  
  #pragma omp for reduction(+ :sum) schedule(runtime)
  for (int i=0;i<n;++i)
  {
	sum+=arr[i];
  }


  }
 
  cout<<sum;
  delete[] arr;
  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();

  

  return 0;

}
