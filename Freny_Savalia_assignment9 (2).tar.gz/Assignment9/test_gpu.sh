#!/bin/sh

./polynomial_gpu 10000 10

