#include <iostream>
#include <cmath>
#include <cstdlib>
#include <chrono>
#include <mpi.h>
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

  
int main (int argc, char* argv[]) {
  
  if (argc < 6) {
    std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }

  int size, rank;

  MPI_Init(&argc,&argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  int functionid=std::stoi(argv[1]);
  float a=std::stof(argv[2]);
  float b=std::stof(argv[3]);
  float n=std::stoi(argv[4]);
  int intensity=std::stoi(argv[5]);
  
  float u;
  u=(b-a)/n;
  //cout<<"U"<<u<<endl;
  float output;  

  auto t1=std::chrono::high_resolution_clock::now();

  MPI_Bcast(&n,1,MPI_FLOAT,0,MPI_COMM_WORLD);

  float x;
  float result;
  float sum;
  
  
  switch(functionid){
  case 1:
       for(int i=rank; i<n; i+=size){
           x=(a+(i+0.5)*u);
	   sum+=f1(x,intensity);
       }
       
       break;
  case 2:
       for(int i=rank; i<n; i+=size){
           x=(a+(i+0.5)*u);
           sum+=f2(x,intensity);
       }
       
       break;
       
  case 3:
       for(int i=rank; i<n; i+=size){
           x=(a+(i+0.5)*u);
           sum+=f3(x,intensity);
       }
       
       break;
  case 4:
       for(int i=rank; i<n; i+=size){
           x=(a+(i+0.5)*u);
           sum+=f4(x,intensity);
       }
       
       break;
  default:
       std::cout<<"\nPlease enter an integer value between 1 to 4\n";
       break;
  }
  
  //cout<<"U"<<u<<endl;
  //cout<<"SUM"<<sum<<endl;
  //cout<<"RESULT"<<result<<endl;

  MPI_Reduce(&sum,&result,1,MPI_FLOAT,MPI_SUM,0,MPI_COMM_WORLD);
  
  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  
  if(rank == 0){
	output=u*result;
  	cout<<output<<endl;
        //cout<<"RESULT"<<result<<endl;
        std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();
  }

  MPI_Finalize();

  return 0;
}
