#!/bin/sh

mpirun ./hello
