#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

using namespace std;


void* f(void* arg){

	long number = (long) arg;
	printf("Hello! I am thread %d ",number);
	return 0;	

}


int main (int argc, char* argv[]) {

	if (argc < 2) {
		std::cerr<<"usage: "<<argv[0]<<" <nbthreads>"<<std::endl;
		return -1;
	}
	
	
	int num;
	sscanf(argv[1],"%d",&num);
	
	
	pthread_t cthread[50];
	
	for(int i=0;i<=num;++i){
		
		pthread_create(&cthread[i], NULL, f, (void *)i);	

	}
	
	for(int i=0;i<=num;i++){
		pthread_join(cthread[i], NULL);	

	}



  
	return 0;
}
