#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <string.h>
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

  void generateReduceData (int* arr, size_t n);

#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand

  
  if (argc < 3) {
    std::cerr<<"usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int * arr = new int [n];
  int nbthreads = atoi(argv[2]);
  int sum = 0;
  generateReduceData (arr, atoi(argv[1]));
  omp_set_num_threads(nbthreads);
  omp_set_dynamic(0);
  auto t1=std::chrono::high_resolution_clock::now();
  //for(int i=0;i<n;i++)
     //cout<<"Arr"<<arr[i]<<endl;
  int partial=0;

#pragma omp parallel private(partial)
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  int begin=0;
  #pragma omp for schedule(dynamic)
   for(int i=0;i<nbthreads;i++){
      int j,stop;
      if(i == nbthreads-1){
        stop = n;
      }
      else{
        stop = (n/nbthreads) * (i+1);
      }     
      #pragma omp task
      {
         int partial=0;
         for(j=begin;(j<stop)&&(j<n);j++){
            //cout<<"Begin"<<begin<<endl;
            //cout<<"End"<<stop<<endl;
            partial+=arr[j];
            //cout<<"Partial"<<partial<<endl;
         }
         #pragma omp critical
         {
            sum+=partial;
            //cout<<"Sum"<<sum<<endl;
         }
      }
      begin=stop;
   }

  }
  cout<<sum;
  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();
  //insert reduction code here
  
  
  delete[] arr;

  return 0;
}
