#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <algorithm>
#include <chrono>
#include <cstring>
#include <cstdint>


#ifdef __cplusplus
extern "C" {
#endif

  void generateMergeSortData (int* arr, size_t n);
  void checkMergeSortResult (int* arr, size_t n);

  
#ifdef __cplusplus
}
#endif


void merge(int *arr, int n, int *temp) {
   int i = 0;
   int j = n/2;
   int k = 0;

   while (i<n/2 && j<n) {
      if (arr[i] < arr[j]) {
         temp[k] = arr[i];
         k++; 
	 i++;
      } else {
         temp[k] = arr[j];
         k++; 
	 j++;
      }
   }
   while (i<n/2) { 
      temp[k] = arr[i];
      k++; 
      i++;
   }
   while (j<n) { 
      temp[k] = arr[j];
      k++; 
      j++;
   }
   std::memcpy(arr, temp, n*sizeof(int));
   
}

void mergesort(int *arr, int n, int *temp,int t)
{
   if (n < 2) return;
   
   if(n>=t){
	   #pragma omp task
	   mergesort(arr, (int)n/2, temp,t);
	   
	   #pragma omp taskwait 

	   #pragma omp task
	   mergesort(arr+(n/2), n-(int)(n/2), temp,t);
	 
	   #pragma omp taskwait
   }
   else{
	   mergesort(arr, (int)n/2, temp,t);
	   mergesort(arr+(n/2), n-(int)(n/2), temp,t);
	  }
	 
   merge(arr, n, temp);
}




int main (int argc, char* argv[]) {

  //forces openmp to create the threads beforehand
  
  if (argc < 3) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }


  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
  omp_set_num_threads(nbthreads);

  #pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  int * arr = new int [n];
  int * temp=(int*)malloc(n * sizeof(int));

  generateMergeSortData (arr, n);
  
  int chunk = n/nbthreads;
  auto t1=std::chrono::high_resolution_clock::now();
  
   #pragma omp parallel
   {
      #pragma omp single
      mergesort(arr, n, temp,chunk);
   }
  
  checkMergeSortResult (arr, n); 
  
  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();
  
  
  
  delete[] arr;
  

return 0;
}