#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <chrono>
#include <omp.h>
#include <iostream>

using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

  void generateMergeSortData (int* arr, size_t n);
  void checkMergeSortResult (const int* arr, size_t n);

#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {


  //forces openmp to create the threads beforehand
  
  if (argc < 3) { std::cerr<<"usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
  
  omp_set_num_threads(nbthreads);

  // get arr data
  int * arr = new int [n];
  generateMergeSortData (arr, n);
  //for(int i=0;i<n;i++)
  	//cout<<"A"<<arr[i]<<endl;

  #pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }

  auto t1=std::chrono::high_resolution_clock::now();
  //insert sorting code here.
  

  for(int i=0;i<n;i++)
  {
	
  	if(i%2 == 0)
	{
		#pragma omp parallel for
		for(int j=0;j<n;j+=2)
		{       
			if(j==(n-1))
				arr[j]=arr[j];
			else if(arr[j]>arr[j+1])
			{
				int t=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=t;
			}
			//for(int k=0;k<n;k++)
  				//cout<<"Ar"<<arr[k]<<endl;
		}
	}
	else
	{
		#pragma omp parallel for
		for(int j=1;j<(n-1);j+=2)
		{
			
			if(arr[j]>arr[j+1])
			{
				int t=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=t;
			}	
			//for(int k=0;k<n;k++)
  				//cout<<"Ar"<<arr[k]<<endl;		
		}
	}
  }
  //for(int i=0;i<n;i++)
  	//cout<<"Ar"<<arr[i]<<endl;

  
  checkMergeSortResult (arr, n);
  cout<<endl;
  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();

  delete[] arr;

  return 0;
}
