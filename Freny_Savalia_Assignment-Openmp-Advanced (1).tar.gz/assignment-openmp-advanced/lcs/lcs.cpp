#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <omp.h>
#include <chrono>

using namespace std;


#ifdef __cplusplus
extern "C" {
#endif

  void generateLCS(char* X, int m, char* Y, int n);
  void checkLCS(char* X, int m, char* Y, int n, int result);

#ifdef __cplusplus
}
#endif



int main (int argc, char* argv[]) {

  //forces openmp to create the threads beforehand


  if (argc < 4) { std::cerr<<"usage: "<<argv[0]<<" <m> <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int m = atoi(argv[1]);
  int n = atoi(argv[2]);
  int nbthreads = atoi(argv[3]);

  // get string data 
  char *X = new char[n];
  char *Y = new char[m];
  generateLCS(X, m, Y, n);
  
  omp_set_num_threads(nbthreads);

  #pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
  
  int r = m;
  int c = n;
  
  int** matrix = (int**)malloc((r+1) * sizeof(int*));

  for(int i=0;i<r;i++)
  {
  	matrix[i] = (int*)malloc((c+1)* sizeof(int));
  }
  m=r+1;
  n=c+1;

  auto t1=std::chrono::high_resolution_clock::now();

  #pragma omp parallel for
  for(int i=0;i<n;i++)
  {
  	matrix[0][i]=0;
  }
  
  #pragma omp parallel for
  for(int i=0;i<n;i++)
  {
  	matrix[i][0]=0;
  }
  
  for (int slice=2;slice<(m+n-1);slice++)
  {
  	int z1 = slice<n?1:slice-n+1;
  	int z2 = slice<m?1:slice-m+1;
	int z3 = slice-z2;
	
	#pragma omp parallel for
	for(int j=z3;j>=z1;j--)
	{
		if (X[j-1] == Y[slice-j-1])
		{
			matrix[j][slice-j] = (matrix[j-1][slice-j-1])+1;
		}
		else
		{
			matrix[j][slice-j] = std::max(matrix[j][slice-j-1] , matrix[j-1][slice-j]);
		}
	}


  }

  //insert LCS code here.
  int result = -1; // length of common subsequence

  auto t2=std::chrono::high_resolution_clock::now();
  typedef std::chrono::duration<float> float_seconds;
  std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();

  checkLCS(X, m, Y, n, result);


  return 0;
}
