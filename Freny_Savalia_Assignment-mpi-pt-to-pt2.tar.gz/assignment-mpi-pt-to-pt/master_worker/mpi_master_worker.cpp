#include <mpi.h>
#include <iostream>
using namespace std;
#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

int main (int argc, char* argv[]) {
  int interval = 0;
  MPI_Init(&argc,&argv);

  if (argc < 6) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <functionid> <a> <b> <n> <intensity>"<<std::endl;
    return -1;
  }

  
  struct timespec t1,t2;

  int functionid = atoi(argv[1]);
  float a = atof(argv[2]);
  float b = atof(argv[3]);
  int n = atoi(argv[4]);
  int intensity = atoi(argv[5]);
  int p,P;
  float globalSum;
  float result;

  MPI_Status status;
  MPI_Comm_rank(MPI_COMM_WORLD, &p);
  MPI_Comm_size(MPI_COMM_WORLD, &P);

  int t = 0;
  int chunk= n/P;
  int* arr = new int[2];
  int TAG;

  clock_gettime(CLOCK_MONOTONIC_RAW, &t1);

  if(p == 0)
  {         
  for(int i = 1; i < P; i++){
	arr[0] = interval;
	arr[1] = interval + chunk;
	TAG = 1;
	t++;
	if(interval > n){
		TAG = 0;
		t--;
        }        
        else if((interval+chunk) > n){
        	arr[1] = n;
	}
        MPI_Send(arr, 2, MPI_INT, i, TAG, MPI_COMM_WORLD);
        interval += chunk;   
  }

  while(t != 0){
	MPI_Recv(&result, 1, MPI_FLOAT, MPI_ANY_SOURCE, 1, MPI_COMM_WORLD, &status);
        if(status.MPI_TAG == 0){
        	t--;
        }
        t--;   
        globalSum += result;
        arr[0] = interval;
        arr[1] = interval + chunk;
        TAG = 1;
        t++;
        if(interval >= n){
		TAG = 0;
		t--;
        }              
	else if((interval+chunk) > n){
        	arr[1] = n;
	}
        MPI_Send(arr, 2, MPI_INT, status.MPI_SOURCE, TAG, MPI_COMM_WORLD);
        interval += chunk;
  }
  }
  else{
	int* temp = new int[2];	 
	MPI_Recv(temp, 2, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
	float x;
	while(&status.MPI_TAG!=0){
		float sum = 0.0;
		if(temp[1] > n){
			MPI_Send(&sum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
			break;
	  	}
		else if(temp[1] <= n){
  			for(int i= temp[0]; i < temp[1]; i++){

	  		switch(functionid){
				  case 1:
				       x=(a+(i+0.5)*(b-a)/n);
				       sum+=f1(x,intensity);
				       break;
				  case 2:
				       x=(a+(i+0.5)*(b-a)/n);
				       sum+=f2(x,intensity);
				       break;
				  case 3:
				       x=(a+(i+0.5)*(b-a)/n);
				       sum+=f3(x,intensity);
				       break;
				  case 4:
				       x=(a+(i+0.5)*(b-a)/n);
				       sum+=f4(x,intensity);
				       break;
				  default:
				       std::cout<<"\nPlease enter an integer value between 1 to 4\n";
				       break;
				  }
       			}

		 	MPI_Send(&sum, 1, MPI_FLOAT, 0, 1, MPI_COMM_WORLD);

		 	MPI_Recv(temp, 2, MPI_INT, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

    		}
  	}
  }

if(p == 0){
  clock_gettime(CLOCK_MONOTONIC_RAW, &t2);
  float Time = (t2.tv_nsec - t1.tv_nsec) / 1000000000.0 + (t2.tv_sec - t1.tv_sec);
  globalSum = globalSum * ((b-a)/n); 
  cout<< globalSum;
  cerr<<Time << endl;
}

  MPI_Finalize();

  return 0;
}

