#include <mpi.h>
#include <math.h>
#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <time.h>


#ifdef __cplusplus
extern "C" {
#endif

  int check2DHeat(double** H, long n, long rank, long P, long k); //this assumes array of array and grid block decomposition

#ifdef __cplusplus
}
#endif

/***********************************************
 *         NOTES on check2DHeat.
 ***********************************************
 *         
 *  First of, I apologize its wonky. 
 *
 *  Email me ktibbett@uncc.edu with any issues/concerns with this. Dr. Saule or the other
 *    TA's are not familiar with how it works. 
 *
 * Params:
 *  n - is the same N from the command line, NOT the process's part of N
 *  P - the total amount of processes ie what MPI_Comm_size gives you.
 *  k - assumes n/2 > k-1 , otherwise may return false negatives.
 *
 *   
 * Disclaimer:
 ***
 *** Broken for P is 9. Gives false negatives, for me it was always
 ***  ranks 0, 3, 6. I have not found issues with 1, 4, or 16, and these
 ***  are what `make test` will use.
 ***
 *
 * Usage:
 *  When code is WRONG returns TRUE. Short example below
 *  if (check2DHeat(...)) {
 *    // oh no it is (maybe) wrong  
 *    std::cout<<"rank: "<<rank<<" is incorrect"<<std::endl;
 *  }
 *
 *
 *
 *  I suggest commenting this out when running the bench
 *
 *
 * - Kyle
 *
 *************/


// Use similarily as the genA, genx from matmult assignment.
double genH0(long row, long col, long n) {
  double val = (double)(col == (n/2));
  return val;
}

void heat(float** curr, float** last, unsigned long row, unsigned long N){
  for (unsigned long i=1; i<row-1; i++){
	curr[i][0] = ((2 * last[i-1][0]) + (2 * last[i][0]) + (2 * last[i+1][0]) + last[i-1][1] + last[i][1] + last[i+1][1]) / 9;
	curr[i][N-1] = ((2 * last[i-1][N-1]) + (2 * last[i][N-1]) + (2 * last[i+1][N-1]) + last[i-1][N-2] + last[i][N-2] + last[i+1][N-2]) / 9;
	for (unsigned long j=1; j<N-1; j++) {
        	curr[i][j] = (last[i-1][j-1] + last[i][j-1] + last[i+1][j-1] + last[i-1][j] + last[i][j] + last[i+1][j] + last[i-1][j+1] + last[i][j+1] + last[i+1][j+1]) / 9;
	}
  }
}
void distribution(float** last, unsigned long row, unsigned long N, int p)
  {
	  srand(time(NULL));
	  for (unsigned long i=1; i<row; i++) {
	  	for (unsigned long j=0; j<N; j++) {
	      		last[i][j] = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
	    	}
	  }
  }

int main(int argc, char* argv[]) {

  if (argc < 3) {
    std::cerr<<"usage: mpirun "<<argv[0]<<" <N> <K>"<<std::endl;
    return -1;
  }

  int p,P;
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &p);
  MPI_Comm_size(MPI_COMM_WORLD, &P);
  // declare and init command line params
  long N, K;
  N = atol(argv[1]);
  K = atol(argv[2]);
  
  unsigned long i,j;
  unsigned long row = (p == P-1) ? (N/P) + (N%P) + 2 : (N/P) + 2;

  float** ftemp = new float*[row];
  float** stemp = new float*[row];

  for (int i=0; i<row; i++){
  	ftemp[i] = (float*)malloc(N * sizeof(float));
	stemp[i] = (float*)malloc(N * sizeof(float));
	if (ftemp[i] == NULL || stemp[i] == NULL){
		std::cerr<<"Memory allocation not possible."<<std::endl;
		return -1;
	}
  }
  
  float** last = ftemp;
  float** curr = stemp;
  MPI_Request* requests = (p == 0 || p == P-1) ? new MPI_Request[2] : new MPI_Request[4];
  MPI_Status* statuses = new MPI_Status[2];
  distribution(last, row, N, p);
  
  
  auto t1 = std::chrono::system_clock::now();
  
  for (int l=0; l<K; l++){
  	if (P == 1){
		memcpy(curr[0], last[0], N * sizeof(float));
		memcpy(curr[row-1], last[row-1], N * sizeof(float));
	}
	else if(p == 0){
		MPI_Irecv(last[row-1], N, MPI_FLOAT, p+1, 0, MPI_COMM_WORLD, &requests[0]);
		MPI_Isend(last[row-2], N, MPI_FLOAT, p+1, 0, MPI_COMM_WORLD, &requests[1]);
		memcpy(curr[0], last[0], N * sizeof(float));
		MPI_Waitall(1, requests, statuses);
  	}
	else if(p == P-1){
		MPI_Irecv(last[0], N, MPI_FLOAT, p-1, 0, MPI_COMM_WORLD, &requests[0]);
      		MPI_Isend(last[1], N, MPI_FLOAT, p-1, 0, MPI_COMM_WORLD, &requests[1]);
      		memcpy(curr[row-1], last[row-1], N * sizeof(float));
		MPI_Waitall(1, requests, statuses);
	}
	else{
  		MPI_Irecv(last[0], N, MPI_FLOAT, p-1, 0, MPI_COMM_WORLD, &requests[0]);
      		MPI_Irecv(last[row-1], N, MPI_FLOAT, p+1, 0, MPI_COMM_WORLD, &requests[1]);
      		MPI_Isend(last[1], N, MPI_FLOAT, p-1, 0, MPI_COMM_WORLD, &requests[2]);
      		MPI_Isend(last[row-2], N, MPI_FLOAT, p+1, 0, MPI_COMM_WORLD, &requests[3]);
		MPI_Waitall(2, requests, statuses);
  	}
  	heat(curr, last, row, N);
 	curr = (i%2==0) ? ftemp : stemp;
	last = (i%2==0) ? stemp : ftemp;
  }
  

  if (p == 0) {
  	auto t2 = std::chrono::system_clock::now();
  	std::chrono::duration<double> diff = t2-t1;
  	std::cerr<<diff.count()<<std::endl;
  }
    
  MPI_Finalize();
  // use double for heat 2d 

  // write code here


  return 0;
}

























