#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include <cmath>

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

float global_sum=0.0,global_value=0.0;

pthread_mutex_t global_sum_lock;

struct parameters{
	float a,b,x,sum;
	int functionid,intensity;
	int begin,end;
	int n;
	float value=0;
};

void* iteration_sync(void *arg){

	struct parameters* pm=(struct parameters*)arg;
	
	for(int i=pm->begin;i<pm->end;i++){
		
		
		//printf("\nstart:%i",pm->begin);

		//printf("\nend:%i",pm->end);
		pthread_mutex_lock(&global_sum_lock);
	
		switch(pm->functionid){
			case 1:
				
				global_sum+=f1((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
	  		case 2:
	       			global_sum+=f2((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
			case 3:
			        global_sum+=f3((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
			case 4:
			        global_sum+=f4((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
			default:
				std::cout<<"\nPlease enter an integer value between 1 to 4\n";
				break;
			
		}
		pthread_mutex_unlock(&global_sum_lock);
		//printf("%f",global_sum);
	}
	pthread_exit(NULL);	
	
}

void* thread_sync(void *arg){
	
	struct parameters* pm=(struct parameters*)arg;
	float sum=0.0;
	
	for(int i=pm->begin;i<pm->end;i++){
		
	
		switch(pm->functionid){
			case 1:
				sum+=f1((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
	  		case 2:
	       			sum+=f2((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
	       
			case 3:
			        sum+=f3((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
			case 4:
			        sum+=f4((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
	       			break;
			default:
				std::cout<<"\nPlease enter an integer value between 1 to 4\n";
				break;
			
		}
		
	}
	pthread_mutex_lock(&global_sum_lock);
		global_sum=global_sum + sum;
		pthread_mutex_unlock(&global_sum_lock);

	pthread_exit(NULL);
}


int main (int argc, char* argv[]) {
	
		
	if (argc < 8) {
		std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync>"<<std::endl;
		return -1;
	}
	
	int functionid=std::stoi(argv[1]);
	float a=std::stof(argv[2]);
	float b=std::stof(argv[3]);
	int n=std::stoi(argv[4]);
	int intensity=std::stoi(argv[5]);
	int nbthreads=std::stoi(argv[6]);
	char* sync=argv[7];
	float final_sum=0;


	struct parameters* pm;	
	pthread_t* threads;

	pm=(struct parameters*)malloc(nbthreads * sizeof(struct parameters));

	threads=(pthread_t*)malloc(nbthreads * sizeof(pthread_t));
	
	pthread_mutex_init(&global_sum_lock,NULL);

	auto t1=std::chrono::high_resolution_clock::now();
	
	if(strcmp(sync,"iteration") == 0){
	
		for(int i=0;i<nbthreads;i++){
			pm[i].functionid=functionid;
			pm[i].a=a;
			pm[i].b=b;
			pm[i].n=n;
			pm[i].intensity=intensity;
			pm[i].begin=i * n/nbthreads;
			pm[i].end=(i * n/nbthreads) + (n/nbthreads);
			pthread_create(&threads[i],NULL,iteration_sync,(void *)&(pm[i]));
			//printf("\nBegin: %i",pm[i].begin);
			//printf("\nEnd: %i",pm[i].end);	
			//printf("\n");		

		}	
		for(int i=0;i<nbthreads;i++){
			pthread_join(threads[i],NULL);		
		}
		//printf("\ngsum:%f",global_sum);
		 
	}

	else if(strcmp(sync,"thread") == 0){

		for(int i=0;i<nbthreads;i++){
			pm[i].functionid=functionid;
			pm[i].a=a;
			pm[i].b=b;
			pm[i].n=n;
			pm[i].intensity=intensity;
			pm[i].begin=i * n/nbthreads;
			pm[i].end=(i * n/nbthreads) + (n/nbthreads);
			pthread_create(&threads[i],NULL,thread_sync,(void *)&(pm[i]));			

		}	
		for(int j=0;j<nbthreads;j++){
			pthread_join(threads[j],NULL);		
		}
		
		
	}
	//printf("\nvalue:%f",((b-a)/n));
	global_sum*=(b-a)/n;
	printf("%f",global_sum);
	//std::cout<<global_sum;
	//std::cout<<final_sum;
	auto t2=std::chrono::high_resolution_clock::now();
	typedef std::chrono::duration<float> float_seconds;
	std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();

	return 0;

}
