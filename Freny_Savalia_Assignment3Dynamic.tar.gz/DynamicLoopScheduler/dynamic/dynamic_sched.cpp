#include <iostream>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std; 

#ifdef __cplusplus
extern "C" {
#endif


float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif

int startloop=0,work=0;
int granularity,endloop;
float global_sum=0.0;
float final_sum=0.0;
int n;

pthread_mutex_t global_sum_lock,iteration_lock,loop_lock; 

struct parameters{
	float a,b,x,sum;
	int functionid,intensity;
	int start,end;
	int n;
	float value=0;
};



int get_next(){
	int temp;
        pthread_mutex_lock(&loop_lock);
	temp = startloop;
	
	startloop = startloop + granularity;
	
	if (startloop + granularity > n){
		work = 1;
	}
	pthread_mutex_unlock(&loop_lock);
	//printf("\ntemp value:%i",temp);
	return temp;
}

void* iteration_sync(void *arg){

	struct parameters* pm=(struct parameters*)arg;
	pthread_mutex_lock(&loop_lock);
	int tempWork=work;
        pthread_mutex_unlock(&loop_lock);
	while(tempWork!=1){
		pm->start = get_next();
    		pm->end = pm->start + granularity;
		for (int i=pm->start;i<pm->end;i++){
			
			pthread_mutex_lock(&global_sum_lock);
	
			switch(pm->functionid){
				case 1:
					
					global_sum+=f1((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
		  		case 2:
		       			global_sum+=f2((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				case 3:
					global_sum+=f3((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				case 4:
					global_sum+=f4((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				default:
					std::cout<<"\nPlease enter an integer value between 1 to 4\n";
					break;
				
			}
			if (i == pm->end-1 && endloop>=n-1){
			pthread_mutex_lock(&loop_lock);
			
    	  			work = 1;
			pthread_mutex_unlock(&loop_lock);
			}
			pthread_mutex_unlock(&global_sum_lock);		
		}
	}
	pthread_exit(NULL);
}

void* thread_sync(void *arg){
	
	struct parameters* pm=(struct parameters*)arg;
	float sum=0.0;
	
	while(work!=1){
		float partial_sum=0.0;
		pm->start=get_next();
		if(pm->start>=n){
			break;
		}
		pm->end=pm->start + granularity;
		for(int i=pm->start;i<pm->end;i++){
		
	
			switch(pm->functionid){
				case 1:
					partial_sum+=f1((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
		  		case 2:
		       			partial_sum+=f2((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
		       
				case 3:
					partial_sum+=f3((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				case 4:
					partial_sum+=f4((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				default:
					std::cout<<"\nPlease enter an integer value between 1 to 4\n";
					break;
				
			}
		
		}
		sum+=partial_sum;
		
	}
	pthread_mutex_lock(&global_sum_lock);
	if (endloop>=n-1){
    	  	work = 1;
	}
	global_sum=global_sum + sum;
	pthread_mutex_unlock(&global_sum_lock);
	
	pthread_exit(NULL);
	

}


void* chunk_sync(void *arg){
	struct parameters* pm=(struct parameters*)arg;
	
	while(work!=1){
		float chunk_sum = 0.0;
		int loop_start,loop_end;
		loop_start=get_next();		
		loop_end=loop_start + granularity;
		if(loop_end<=n){
		
		for(int i=loop_start;i<loop_end;i++){
			switch(pm->functionid){
				case 1:
					chunk_sum+=f1((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
		  		case 2:
		       			chunk_sum+=f2((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				case 3:
					chunk_sum+=f3((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				case 4:
					chunk_sum+=f4((pm->a +((i+0.5) * ((pm->b - pm->a)/(float)pm->n))),pm->intensity);
		       			break;
				default:
					std::cout<<"\nPlease enter an integer value between 1 to 4\n";
					break;
				
			}	
		}
		}
		pthread_mutex_lock(&global_sum_lock);
		if (endloop>=n-1){
    	  		work = 1;
		}
		global_sum+=chunk_sum;		
    		pthread_mutex_unlock(&global_sum_lock);		
	}
	pthread_exit(NULL);
	
	
}


int main (int argc, char* argv[]) {

	if (argc < 9) {
		std::cerr<<"usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <sync> <granularity>"<<std::endl;
		return -1;
	}
	
	int functionid=std::stoi(argv[1]);
	float a=std::stof(argv[2]);
	float b=std::stof(argv[3]);
	n=std::stoi(argv[4]);
	int intensity=std::stoi(argv[5]);
	int nbthreads=std::stoi(argv[6]);
	char* sync=argv[7];
	granularity=std::stoi(argv[8]);
	struct parameters* pm;	
	pthread_t* threads;
	
	pm=(struct parameters*)malloc(nbthreads * sizeof(struct parameters));

	threads=(pthread_t*)malloc(nbthreads * sizeof(pthread_t));

	auto t1=std::chrono::high_resolution_clock::now();

	if(strcmp(sync,"iteration") == 0){
	
		for(int i=0;i<nbthreads;i++){
			pm[i].functionid=functionid;
			
			pm[i].a=a;
			pm[i].b=b;
			pm[i].n=n;
			pm[i].intensity=intensity;
			pthread_create(&threads[i],NULL,iteration_sync,(void *)&(pm[i]));
					

		}	
		for(int i=0;i<nbthreads;i++){
			pthread_join(threads[i],NULL);		
		}
		
	}
	else if(strcmp(sync,"thread") == 0){

		for(int i=0;i<nbthreads;i++){
			pm[i].functionid=functionid;
			pm[i].a=a;
			pm[i].b=b;
			pm[i].n=n;
			pm[i].intensity=intensity;
			pthread_create(&threads[i],NULL,thread_sync,(void *)&(pm[i]));			

		}	
		for(int j=0;j<nbthreads;j++){
			pthread_join(threads[j],NULL);		
		}
	
	}
	else if(strcmp(sync,"chunk") == 0){
		
		for(int i=0;i<nbthreads;i++){
			pm[i].functionid=functionid;
			pm[i].a=a;
			pm[i].b=b;
			pm[i].n=n;
			pm[i].intensity=intensity;
			pthread_create(&threads[i],NULL,chunk_sync,(void *)&(pm[i]));
		}
		for(int j=0;j<nbthreads;j++){
			pthread_join(threads[j],NULL);
		}
	}

	
	global_sum*=(b-a)/n;
	std::cout<<global_sum;


	auto t2=std::chrono::high_resolution_clock::now();
	typedef std::chrono::duration<float> float_seconds;
	std::cerr<<std::chrono::duration_cast<float_seconds>(t2-t1).count();
	return 0;
}
